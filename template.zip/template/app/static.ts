export const navLinks = [
  { name: "/foo", url: "/", in: ["header", "footer"] },
  { name: "/bar", url: "/posts", in: ["header", "footer"] },
]
